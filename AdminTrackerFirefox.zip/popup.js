document.addEventListener('DOMContentLoaded', async () => {
    const result = await chrome.storage.local.get('contentChanges');
    const changes = result.contentChanges || [];
    const changesList = document.getElementById('changes-list');

    document.getElementById('clearHistory').addEventListener('click', async () => {
        await chrome.storage.local.set({ contentChanges: [] });
        changesList.textContent = '';
    });

    changes.reverse().forEach(change => {
        const changeElement = document.createElement('div');
        changeElement.className = 'change-item';

        const timestamp = document.createElement('div');
        timestamp.className = 'timestamp';
        timestamp.textContent = change.timestamp;

        const oldValue = document.createElement('div');
        oldValue.className = 'old-value';
        oldValue.textContent = change.oldValue;

        const newValue = document.createElement('div');
        newValue.className = 'new-value';
        newValue.textContent = change.newValue;

        changeElement.appendChild(timestamp);
        changeElement.appendChild(oldValue);
        changeElement.appendChild(newValue);
        
        changesList.appendChild(changeElement);
    });
});