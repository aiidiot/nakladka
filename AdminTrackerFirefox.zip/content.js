// content.js
class ContentTracker {
    constructor() {
        this.elementValues = new Map();
        this.startTracking();
    }

    startTracking() {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                const targetNode = mutation.target;
                if (targetNode.nodeName === '#text' && targetNode.parentElement?.matches('span[style*="word-break: break-all"]')) {
                    const url = this.findUrlInAccordion(targetNode.parentElement);
                    if (url) {
                        this.handleChange(targetNode.parentElement, url);
                    }
                }
            });
        });

        observer.observe(document, {
            childList: true,
            subtree: true,
            characterData: true,
            characterDataOldValue: true
        });

        // Initial values
        document.querySelectorAll('span[style*="word-break: break-all"]').forEach(span => {
            const url = this.findUrlInAccordion(span);
            if (url) {
                this.elementValues.set(span, {
                    text: span.textContent.trim(),
                    url: url
                });
            }
        });
    }

    findUrlInAccordion(element) {
        // Przechodzimy w górę do znalezienia głównego kontenera akordeonu
        let current = element;
        while (current && !current.classList.contains('AccordionSummary__SummaryContainer')) {
            current = current.parentElement;
        }
        if (current) {
            // Szukamy elementu z URLem w następnym rodzeństwie
            let nextElement = current.nextElementSibling;
            if (nextElement) {
                const urlInput = nextElement.querySelector('input[type="text"]');
                return urlInput ? urlInput.value : null;
            }
        }
        return null;
    }

    async handleChange(element, currentUrl) {
        const newValue = element.textContent.trim();
        const storedValue = this.elementValues.get(element);

        if (storedValue && storedValue.text !== newValue) {
            const change = {
                timestamp: new Date().toLocaleString(),
                oldValue: storedValue.text,
                oldUrl: storedValue.url,
                newValue,
                newUrl: currentUrl
            };

            const result = await chrome.storage.local.get('contentChanges');
            const changes = result.contentChanges || [];
            changes.push(change);
            await chrome.storage.local.set({ 
                contentChanges: changes.slice(-50)
            });
        }

        this.elementValues.set(element, {
            text: newValue,
            url: currentUrl
        });
    }
}

if (window.location.href.includes('n2cr-config-admin.grupawp.pl')) {
    setTimeout(() => new ContentTracker(), 1000);
}