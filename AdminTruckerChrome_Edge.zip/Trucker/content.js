// content.js
class ContentTracker {
    constructor() {
        this.elementValues = new Map();
        this.startTracking();
    }

    startTracking() {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                const targetNode = mutation.target;
                if (targetNode.nodeName === '#text' && targetNode.parentElement?.matches('span[style*="word-break: break-all"]')) {
                    this.handleChange(targetNode.parentElement);
                }
                
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        const spans = node.querySelectorAll('span[style*="word-break: break-all"]');
                        spans.forEach(span => this.handleChange(span));
                    }
                });
            });
        });

        observer.observe(document, {
            childList: true,
            subtree: true,
            characterData: true,
            characterDataOldValue: true
        });

        // Initial values
        document.querySelectorAll('span[style*="word-break: break-all"]').forEach(span => {
            this.elementValues.set(span, span.textContent.trim());
        });
    }

    async handleChange(element) {
        const newValue = element.textContent.trim();
        const oldValue = this.elementValues.get(element);

        if (oldValue && oldValue !== newValue && oldValue.length > 5) {
            console.log('Change detected:', {oldValue, newValue}); // Debug log
            
            const change = {
                timestamp: new Date().toLocaleString(),
                oldValue,
                newValue
            };

            const result = await chrome.storage.local.get('contentChanges');
            const changes = result.contentChanges || [];
            changes.push(change);
            await chrome.storage.local.set({ contentChanges: changes.slice(-50) });
        }

        this.elementValues.set(element, newValue);
    }
}

// Start tracking with a small delay to ensure DOM is loaded
if (window.location.href.includes('n2cr-config-admin.grupawp.pl')) {
    setTimeout(() => new ContentTracker(), 1000);
}