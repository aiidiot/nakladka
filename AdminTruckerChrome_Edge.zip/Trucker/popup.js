document.addEventListener('DOMContentLoaded', async () => {
    const result = await chrome.storage.local.get('contentChanges');
    const changes = result.contentChanges || [];
    const changesList = document.getElementById('changes-list');

    document.getElementById('clearHistory').addEventListener('click', async () => {
        await chrome.storage.local.set({ contentChanges: [] });
        changesList.innerHTML = '';
    });

    changes.reverse().forEach(change => {
        const changeElement = document.createElement('div');
        changeElement.className = 'change-item';
        changeElement.innerHTML = `
            <div class="timestamp">${change.timestamp}</div>
            <div class="old-value">${change.oldValue}</div>
            <div class="new-value">${change.newValue}</div>
        `;
        changesList.appendChild(changeElement);
    });
});